db.articles.insertMany([
    {_id:1, subject:'Core Java', author:'abc', views:60},
    {_id:2, subject:'Adv Java', author:'def', views:50},
    {_id:3, subject:'Spring', author:'ghi', views:70},
    {_id:4, subject:'Spring boot', author:'pqr', views:60},
    {_id:5, subject:'Spring microservices with Java', author:'def', views:40},
    {_id:6, subject:'Java framework', author:'xyz', views:10},
    {_id:7, subject:'MongoDB', author:'lmn', views:100}
]);