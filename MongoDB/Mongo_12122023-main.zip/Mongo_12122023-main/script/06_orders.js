db.orders.insertMany([
    {_id:0, name:'Pepperoni', size: 'small', price:100, quantity:10, date:ISODate("2023-03-15T08:08:05Z")},
    {_id:1, name:'Pepperoni', size: 'medium', price:200, quantity:20, date:ISODate("2023-03-15T08:08:05Z")},
    {_id:2, name:'Pepperoni', size: 'large', price:300, quantity:30, date:ISODate("2023-03-17T08:08:05Z")},
    {_id:3, name:'cheese', size: 'small', price:120, quantity:15, date:ISODate("2023-03-15T08:08:05Z")},
    {_id:4, name:'cheese', size: 'medium', price:130, quantity:50, date:ISODate("2023-01-15T08:08:05Z")},
    {_id:5, name:'cheese', size: 'large', price:140, quantity:10, date:ISODate("2023-01-15T08:08:05Z")},
    {_id:6, name:'paneer', size: 'small', price:100, quantity:10, date:ISODate("2023-01-15T08:08:05Z")},
    {_id:7, name:'panner', size: 'medium', price:200, quantity:40, date:ISODate("2023-03-15T08:08:05Z")},
    {_id:8, name:'panner', size: 'large', price:300, quantity:10, date:ISODate("2023-01-15T08:08:05Z")}  
]);