db.emp.deleteOne({name:'Ajay'});
db.emp.deleteMany({name:'Ajay'});